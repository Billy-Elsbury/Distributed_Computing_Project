import java.util.List;

public class SMPThread implements Runnable {
    private MyStreamSocket myDataSocket;
    private MessageStorage messageStorage = MessageStorage.getInstance();  // Use the singleton instance
    private String username = null;  // Track the username for this session

    public SMPThread(MyStreamSocket myDataSocket) {
        this.myDataSocket = myDataSocket;
    }

    public void run() {
        boolean done = false;
        String message = "";

        try {
            while (!done) {
                // Receive a message from the client
                message = myDataSocket.receiveMessage();
                System.out.println("Message received: " + message);

                // Split the message into parts
                String[] parts = message.split(" ", 4);  // Split into at most 4 parts
                if (parts.length == 0) {
                    myDataSocket.sendMessage("102 Invalid command format.");
                    continue;
                }

                String command = parts[0].toUpperCase();

                switch (command) {
                    case "LOGIN":
                        if (parts.length == 3) {
                            String username = parts[1];
                            String password = parts[2];
                            this.username = username;
                            myDataSocket.sendMessage(ErrorCodes.SUCCESS + " Login successful.");
                        } else {
                            myDataSocket.sendMessage(ErrorCodes.INVALID_LOGIN_FORMAT + " Invalid login format. Usage: LOGIN <username> <password>");
                        }
                        break;

                    case "UPLOAD":
                        if (parts.length == 4) {
                            String username = parts[1];
                            if (this.username == null || !this.username.equals(username)) {
                                myDataSocket.sendMessage(ErrorCodes.NOT_LOGGED_IN + " Not logged in.");
                                break;
                            }
                            try {
                                int id = Integer.parseInt(parts[2]);
                                String messageContent = parts[3];
                                if (messageContent.isEmpty()) {
                                    myDataSocket.sendMessage(ErrorCodes.EMPTY_MESSAGE + " Message content cannot be empty.");
                                } else if (messageStorage.addMessage(username, id, messageContent)) {
                                    myDataSocket.sendMessage(ErrorCodes.SUCCESS + " Message uploaded.");
                                } else {
                                    myDataSocket.sendMessage(ErrorCodes.MESSAGE_ID_EXISTS + " Message ID already exists.");
                                }
                            } catch (NumberFormatException e) {
                                myDataSocket.sendMessage(ErrorCodes.INVALID_MESSAGE_ID + " Invalid message ID.");
                            }
                        } else {
                            myDataSocket.sendMessage(ErrorCodes.INVALID_UPLOAD_FORMAT + " Invalid upload format. Usage: UPLOAD <username> <ID> <message>");
                        }
                        break;

                    case "DOWNLOAD_ALL":
                        List<String> allMessages = messageStorage.getAllMessages();
                        String response = String.join("|", allMessages);  // Join messages with a delimiter
                        myDataSocket.sendMessage(response);
                        break;

                    case "DOWNLOAD":
                        if (parts.length == 2) {
                            String input = parts[1];
                            if (input.isEmpty()) {
                                myDataSocket.sendMessage(ErrorCodes.NO_MESSAGE_ID_PROVIDED + " No message ID provided. Usage: DOWNLOAD <ID>");
                            } else {
                                try {
                                    int messageId = Integer.parseInt(input);
                                    String specificMessage = messageStorage.getMessageById(this.username, messageId);
                                    myDataSocket.sendMessage(specificMessage);
                                } catch (NumberFormatException e) {
                                    myDataSocket.sendMessage(ErrorCodes.INVALID_MESSAGE_ID + " Invalid message ID.");
                                }
                            }
                        } else {
                            myDataSocket.sendMessage(ErrorCodes.INVALID_DOWNLOAD_FORMAT + " Invalid download format. Usage: DOWNLOAD <ID>");
                        }
                        break;

                    case "CLEAR":
                        if (parts.length == 1) {
                            try {
                                messageStorage.clearMessages();
                                myDataSocket.sendMessage(ErrorCodes.SUCCESS + " All messages cleared.");
                            } catch (Exception ex) {
                                myDataSocket.sendMessage(ErrorCodes.ERROR_CLEARING_MESSAGES + " Error clearing messages.");
                            }
                        } else {
                            myDataSocket.sendMessage(ErrorCodes.INVALID_CLEAR_FORMAT + " Invalid clear format. Usage: CLEAR");
                        }
                        break;

                    case "LOGOFF":
                        if (parts.length == 2) {
                            String username = parts[1];
                            if (this.username == null || !this.username.equals(username)) {
                                myDataSocket.sendMessage(ErrorCodes.NOT_LOGGED_IN + " Not logged in.");
                                break;
                            }
                            this.username = null;
                            myDataSocket.sendMessage(ErrorCodes.SUCCESS + " Logoff successful.");
                            myDataSocket.close();
                            done = true;
                        } else {
                            myDataSocket.sendMessage(ErrorCodes.INVALID_LOGOFF_FORMAT + " Invalid logoff format. Usage: LOGOFF <username>");
                        }
                        break;

                    default:
                        myDataSocket.sendMessage(ErrorCodes.UNKNOWN_COMMAND + " Unknown command.");
                        break;
                }
            }
        } catch (Exception ex) {
            System.out.println("Exception caught in thread: " + ex);
        }
    }
}